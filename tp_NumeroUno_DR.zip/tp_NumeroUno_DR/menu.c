#include <stdio.h>
#include <stdio_ext.h>
#include "funciones.h"


void menuOpciones(void) {
int menu;
float x, y,resSum, resRes, resMult, resDivi;
int resUno, resDos;
int acumulador=0; //usado a fin de informar que en caso de que si no se caculan las operaciones antes de informar resultados, pueden mostrarse resultados de operaciones anteriores.

int flagA=0;//cuando el case1 este cumplido=1.Utilizado para mostrar operandos actuales
int flagB=0;//cuando el case2 este cumplido=1
int flagC=0;//usado en división, a fin de que no sea posible que el divisor sea cero.
int flagD=0;//usado en factorial
int flagE=0;//usado en factorial
int flagF=0;//cuando el case3 este cumplido=1.Utilizado para informar que no pueden mostrarse resultados sin antes realizar operaciones.


printf("\n\n¡Bienvenido! \nEsta calculadora opera con números racionales, mostrando seis decimales, para suma, resta, división y multiplicación. Para la operación factorial acepta numeros naturales hasta el 12 inclusive: en caso de ingresar numeros con coma, se tendrá en cuenta solo los números enteros, y si se ingresan números negativos, no se ejecutará la operación.\nSeleccione una opción:\n");

do{

if(flagA==0&&flagB==0){
printf("\n\n1.Ingresar el primer operando");
printf("\n2.Ingresar el segundo operando");
printf("\n3.Calcular operaciones");
printf("\n4.Mostrar resultados");
printf("\n5.Salir\n\n");
} else if (flagA==1&&flagB==0) {
printf("\n\n1.Ingresar otro primer operando. El primer operando ingresado actualmente es %f", x);
printf("\n2.Ingresar el segundo operando");
printf("\n3.Calcular operaciones");
printf("\n4.Mostrar resultados");
printf("\n5.Salir\n\n");
} else if(flagA==0&&flagB==1){
printf("\n\n1.Ingresar el primer operando");
printf("\n2.Ingresar otro segundo operando. El segundo operando ingresado actualmente es %f", y);
printf("\n3.Calcular operaciones");
printf("\n4.Mostrar resultados");
printf("\n5.Salir\n\n");
} else {
printf("\n\n1.Ingresar otro primer operando. El primer operando ingresado actualmente es %f", x);
printf("\n2.Ingresar otro segundo operando. El segundo operando ingresado actualmente es %f", y);
printf("\n3.Calcular operaciones");
printf("\n4.Mostrar resultados");
printf("\n5.Salir\n\n");
}

if (acumulador>=3) {printf("¡ATENCIÓN! Si usted calculó las operaciones previamente con operandos distintos a los actuales, recuerde calcularlas nuevamente antes de seleccionar \"Mostrar Resultados\". De lo contrario, los resultados arrojados serán los correspondientes a las operaciones realizadas con los operandos anteriores.\n");
acumulador--;
}

scanf("%d", &menu);


switch(menu){
case 1:
printf("Ingrese el primer operando: ");
scanf("%f", &x);
printf("Usted ingresó %f como primer operando\n", x);
flagA=1;

int a = (int) x;


acumulador++;

break;

case 2:
printf("Ingrese el segundo operando: ");
scanf("%f", &y);
printf("Usted ingresó %f como primer operando\n", y);
flagB=1;

int b= (int) y;

acumulador++;

break;

case 3:
if (flagA!=1){
printf("Por favor ingrese los dos operandos para que sea posible calcular la operación\n");
menu=1;
}else if (flagB!=1){
printf("Por favor ingrese los dos operandos para que sea posible calcular la operación\n");
menu=2;
}else{
resSum= suma(x,y);
resRes=resta(x,y);
resMult=multiplicacion(x,y);

if(y!=0){resDivi=division(x, y);
}else {flagC=1;}

if ( a>=0&&a<=12){
resUno=factorial(a);
}else if (a<0){
flagD=1;
}else if (a>12){
flagD=2;
}
if ( b>=0&&b<=12){
resDos=factorial(b);
}else if (b<0){
flagE=1;
}else if (b>12){
flagE=2;
}
printf("Las operaciones fueron realizadas\n");
flagF=1;
}
break;

case 4:

if (flagA!=1||flagB!=1){
printf("\nPor favor ingrese los dos operandos para que sea posible calcular la operación\n");
 }else if (flagF!=1){
  printf("\nPara mostrar los resultados, primero debe calcular operaciones\n");
} else{

printf("El resultado de la suma entre %f y %f es %f\n",x,y, resSum);
printf("El resultado de la resta entre %f y %f es %f\n",x,y, resRes);
printf("El resultado de la multiplicación entre %f y %f es %f\n",x,y, resMult);

if (flagC==0){printf("El resultado de la división entre %f y %f es %f\n",x,y, resDivi);
}else{printf("No es posible realizar la división dado que el divisor es cero\n");}

if(flagD==0){printf("El resultado de la operación factorial %d! es %d\n",a, resUno);
}else if (flagD==1)
{printf("No es posible calcular el factorial de %d por ser un número negativo\n",a);
}else {printf("No es posible calcular el factorial de %d por ser un número mayor a 12\n",a);}

if(flagE==0){printf("El resultado de la operación factorial %d! es %d\n",b, resDos);
}else if (flagE==1)
{printf("No es posible calcular el factorial de %d por ser un número negativo\n",b);
}else {printf("No es posible calcular el factorial de %d por ser un número mayor a 12\n",b);}
}
break;

case 5:
printf("¡Hasta la próxima!\n");
break;

default:
printf("Ingrese una opción válida");
}

} while (menu!=5);

}
