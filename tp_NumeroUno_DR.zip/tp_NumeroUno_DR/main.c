#include <stdio.h>
#include <stdlib.h>
#include "menu.h"

int main()
{
    menuOpciones();
    return 0;
}
